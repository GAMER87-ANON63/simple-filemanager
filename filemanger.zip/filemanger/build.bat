@echo off
echo Compiling C++ Terminal File Manager...
g++ -std=c++20 main.cpp -o filemanager.exe -lshlwapi
if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    exit /b %ERRORLEVEL%
)
echo Compilation successful! Run filemanager.exe to start.
