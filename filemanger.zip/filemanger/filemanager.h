#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <windows.h>
#include <shlwapi.h>

#pragma comment(lib, "Shlwapi.lib")

namespace fs = std::filesystem;

struct FileEntry {
    std::string name;
    fs::path path;
    bool is_directory = false;
    uint64_t size = 0;
    std::string size_str;
    std::string date_str;
    bool is_executable = false;
    bool is_system = false;
    bool is_zip = false;
};

namespace FileManager {

    // Convert file time to a readable string
    inline std::string formatFileTime(fs::file_time_type ftime) {
        try {
            // Portable way to convert file_time_type to time_t in C++20
            auto sctp = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
                ftime - fs::file_time_type::clock::now() + std::chrono::system_clock::now()
            );
            std::time_t ctime = std::chrono::system_clock::to_time_t(sctp);
            
            std::tm* gmt = std::localtime(&ctime);
            if (!gmt) return "Unknown Date";
            
            std::stringstream ss;
            ss << std::put_time(gmt, "%Y-%m-%d %H:%M:%S");
            return ss.str();
        } catch (...) {
            return "Unknown Date";
        }
    }

    // Format byte sizes to KB, MB, GB, etc.
    inline std::string formatSize(uint64_t bytes, bool is_dir) {
        if (is_dir) return "<DIR>";
        
        double size = static_cast<double>(bytes);
        std::vector<std::string> units = {"B", "KB", "MB", "GB", "TB"};
        int unit_idx = 0;
        
        while (size >= 1024.0 && unit_idx < units.size() - 1) {
            size /= 1024.0;
            unit_idx++;
        }
        
        std::stringstream ss;
        if (unit_idx == 0) {
            ss << bytes << " B";
        } else {
            ss << std::fixed << std::setprecision(1) << size << " " << units[unit_idx];
        }
        return ss.str();
    }

    // Check if the file is an executable (on Windows)
    inline bool checkIsExecutable(const fs::path& path) {
        std::string ext = path.extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        return (ext == ".exe" || ext == ".bat" || ext == ".cmd" || ext == ".msi" || ext == ".ps1");
    }

    // Check if the file is a compressed archive
    inline bool checkIsZip(const fs::path& path) {
        std::string ext = path.extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        return (ext == ".zip" || ext == ".rar" || ext == ".7z" || ext == ".tar" || ext == ".gz" || ext == ".bz2");
    }

    // Check if system file using Windows API
    inline bool checkIsSystem(const fs::path& path) {
        // Dotfiles are treated as system/hidden as a convention
        if (path.filename().string().rfind(".", 0) == 0) {
            return true;
        }
        
        DWORD attribs = GetFileAttributesW(path.wstring().c_str());
        if (attribs != INVALID_FILE_ATTRIBUTES) {
            return (attribs & FILE_ATTRIBUTE_SYSTEM) || (attribs & FILE_ATTRIBUTE_HIDDEN);
        }
        return false;
    }

    // List contents of directory, sorting directories first, then files
    inline std::vector<FileEntry> listDirectory(const fs::path& dir_path, const std::string& filter = "") {
        std::vector<FileEntry> entries;
        
        if (!fs::exists(dir_path) || !fs::is_directory(dir_path)) {
            return entries;
        }

        try {
            for (const auto& entry : fs::directory_iterator(dir_path, fs::directory_options::skip_permission_denied)) {
                try {
                    std::string name = entry.path().filename().string();
                    
                    // Apply simple case-insensitive filter
                    if (!filter.empty()) {
                        std::string name_lower = name;
                        std::string filter_lower = filter;
                        std::transform(name_lower.begin(), name_lower.end(), name_lower.begin(), ::tolower);
                        std::transform(filter_lower.begin(), filter_lower.end(), filter_lower.begin(), ::tolower);
                        if (name_lower.find(filter_lower) == std::string::npos) {
                            continue;
                        }
                    }

                    FileEntry fe;
                    fe.name = name;
                    fe.path = entry.path();
                    fe.is_directory = entry.is_directory();
                    
                    if (!fe.is_directory) {
                        fe.size = entry.file_size();
                        fe.is_executable = checkIsExecutable(fe.path);
                        fe.is_zip = checkIsZip(fe.path);
                    }
                    
                    fe.is_system = checkIsSystem(fe.path);
                    fe.size_str = formatSize(fe.size, fe.is_directory);
                    fe.date_str = formatFileTime(entry.last_write_time());
                    
                    entries.push_back(fe);
                } catch (...) {
                    // Skip files that raise access violations (e.g. system lock files)
                    continue;
                }
            }
        } catch (...) {
            // Parent directory read error
        }

        // Sort: directories first, then alphabetical (case-insensitive)
        std::sort(entries.begin(), entries.end(), [](const FileEntry& a, const FileEntry& b) {
            if (a.is_directory != b.is_directory) {
                return a.is_directory > b.is_directory; // true (1) before false (0)
            }
            std::string name_a = a.name;
            std::string name_b = b.name;
            std::transform(name_a.begin(), name_a.end(), name_a.begin(), ::tolower);
            std::transform(name_b.begin(), name_b.end(), name_b.begin(), ::tolower);
            return name_a < name_b;
        });

        return entries;
    }

    // Check if file is a previewable text file
    inline bool isTextFile(const fs::path& path) {
        std::string ext = path.extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        
        static const std::vector<std::string> txt_extensions = {
            ".txt", ".cpp", ".h", ".hpp", ".c", ".py", ".js", ".json", ".xml", 
            ".html", ".css", ".md", ".cfg", ".ini", ".bat", ".sh", ".yml", ".yaml",
            ".csv", ".log", ".txt", ".sql", ".cmake", ".gitignore"
        };
        
        if (std::find(txt_extensions.begin(), txt_extensions.end(), ext) != txt_extensions.end()) {
            return true;
        }

        // Fallback: examine the first 512 bytes for null characters
        std::ifstream file(path, std::ios::binary);
        if (!file) return false;

        char buf[512];
        file.read(buf, sizeof(buf));
        std::streamsize read_bytes = file.gcount();
        for (std::streamsize i = 0; i < read_bytes; ++i) {
            if (buf[i] == '\0') return false; // Binary null byte indicates binary file
        }
        return read_bytes > 0; // If it's not empty and has no null bytes
    }

    // Get preview of file (either text lines or metadata)
    inline std::vector<std::string> getFilePreview(const FileEntry& entry, int max_lines) {
        std::vector<std::string> preview;
        
        if (entry.is_directory) {
            preview.push_back("Directory Info:");
            preview.push_back("---------------");
            preview.push_back("Name: " + entry.name);
            preview.push_back("Path: " + entry.path.string());
            
            // Count contents
            size_t dirs = 0;
            size_t files = 0;
            try {
                for (const auto& p : fs::directory_iterator(entry.path, fs::directory_options::skip_permission_denied)) {
                    if (p.is_directory()) dirs++;
                    else files++;
                }
                preview.push_back("Contains: " + std::to_string(dirs) + " Directories, " + std::to_string(files) + " Files");
            } catch (...) {
                preview.push_back("Contains: [Permission Denied]");
            }
            return preview;
        }

        if (isTextFile(entry.path)) {
            std::ifstream file(entry.path);
            if (!file) {
                preview.push_back("[Error opening file for preview]");
                return preview;
            }

            std::string line;
            int count = 0;
            while (std::getline(file, line) && count < max_lines) {
                // Remove tab characters for cleaner printing
                std::replace(line.begin(), line.end(), '\t', ' ');
                preview.push_back(line);
                count++;
            }
            if (preview.empty()) {
                preview.push_back("[Empty file]");
            }
            return preview;
        }

        // Non-text files
        preview.push_back("Binary File Metadata:");
        preview.push_back("---------------------");
        preview.push_back("Name: " + entry.name);
        preview.push_back("Path: " + entry.path.string());
        preview.push_back("Size: " + entry.size_str + " (" + std::to_string(entry.size) + " bytes)");
        preview.push_back("Modified: " + entry.date_str);
        preview.push_back("Extension: " + entry.path.extension().string());
        
        return preview;
    }

    // Get disk space info
    inline std::string getDiskSpaceInfo(const fs::path& path) {
        try {
            fs::space_info si = fs::space(path.root_path());
            return "Disk: " + formatSize(si.available, false) + " free / " + formatSize(si.capacity, false) + " total";
        } catch (...) {
            return "Disk: Unknown space";
        }
    }
}
