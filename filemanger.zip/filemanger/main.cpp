#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include <conio.h>
#include <windows.h>
#include <shellapi.h>

#include "tui.h"
#include "filemanager.h"

// Active Application State
fs::path current_path;
std::vector<FileEntry> entries;
int selected_index = 0;
int scroll_offset = 0;
std::string filter_str = "";
std::string status_msg = "Welcome! Use arrow keys to navigate.";
std::string status_clr = TUI::COLOR_SUCCESS;
bool is_running = true;

// Previews
std::vector<std::string> current_preview;

// Function declarations
void refreshDirectory();
void renderScreen();
std::string readInputFromConsole(const std::string& prompt);
bool confirmAction(const std::string& question);
void handleKeyPress();
void performCopy(const fs::path& src);

// Copied file clipboard
fs::path clipboard_path;
bool is_copy_operation = true; // true = copy, false = cut

int main() {
    // Initialize Console UI settings (UTF-8, VT Mode, Hide Cursor)
    if (!TUI::initializeConsole()) {
        std::cerr << "Failed to initialize Windows Terminal VT support.\n";
        return 1;
    }

    // Set starting directory
    current_path = fs::current_path();
    refreshDirectory();

    // Set console title
    SetConsoleTitleW(L"🚀 C++ Terminal File Manager");

    // Main event loop
    while (is_running) {
        renderScreen();
        handleKeyPress();
    }

    TUI::restoreConsole();
    return 0;
}

void refreshDirectory() {
    // Safety check path exists
    if (!fs::exists(current_path)) {
        current_path = fs::current_path();
    }

    // Read files
    entries = FileManager::listDirectory(current_path, filter_str);
    
    // Bounds check selection
    if (selected_index >= static_cast<int>(entries.size())) {
        selected_index = std::max(0, static_cast<int>(entries.size()) - 1);
    }
    if (selected_index < 0) {
        selected_index = 0;
    }

    // Adjust scroll
    int width, height;
    TUI::getTerminalSize(width, height);
    int panel_height = height - 5; // space for header/footer

    if (selected_index < scroll_offset) {
        scroll_offset = selected_index;
    } else if (selected_index >= scroll_offset + panel_height) {
        scroll_offset = selected_index - panel_height + 1;
    }

    // Update preview for current selected item
    current_preview.clear();
    if (!entries.empty()) {
        current_preview = FileManager::getFilePreview(entries[selected_index], panel_height);
    } else {
        current_preview.push_back("[Empty Directory]");
    }
}

void renderScreen() {
    int width, height;
    TUI::getTerminalSize(width, height);

    // Make sure we have a minimum terminal size to display anything
    if (width < 40 || height < 10) {
        TUI::clearScreen();
        std::cout << "Terminal too small to render TUI!" << std::flush;
        return;
    }

    int left_panel_width = (width * 55) / 100; // 55% of width
    int right_panel_width = width - left_panel_width - 3; // accounting for borders
    int panel_height = height - 5;

    std::stringstream screen;
    
    // Move cursor to top-left instead of full clear to prevent flicker
    screen << TUI::moveTo(1, 1);

    // 1. Header (Line 1)
    std::string path_str = " 📂 Path: " + current_path.string();
    std::string disk_info = FileManager::getDiskSpaceInfo(current_path) + " ";
    
    size_t path_limit = width - disk_info.length() - 2;
    if (path_str.length() > path_limit) {
        path_str = " 📂 Path: ..." + path_str.substr(path_str.length() - path_limit + 6);
    }
    
    // Pad header line to full width
    std::string header_line = path_str;
    size_t padding = width - path_str.length() - disk_info.length();
    if (padding > 0) {
        header_line.append(padding, ' ');
    }
    header_line.append(disk_info);
    screen << TUI::COLOR_HEADER << header_line << TUI::RESET << "\n";

    // 2. Panel Top Border (Line 2)
    screen << TUI::COLOR_BORDER << TUI::BOX_TL;
    for (int i = 0; i < left_panel_width; i++) screen << TUI::BOX_HLINE;
    screen << TUI::BOX_TEE_T;
    for (int i = 0; i < right_panel_width; i++) screen << TUI::BOX_HLINE;
    screen << TUI::BOX_TR << TUI::RESET << "\n";

    // 3. Panel Body (Lines 3 to panel_height + 2)
    for (int i = 0; i < panel_height; i++) {
        // Draw Left border
        screen << TUI::COLOR_BORDER << TUI::BOX_VLINE << TUI::RESET;

        // --- LEFT PANEL (File list) ---
        int entry_idx = scroll_offset + i;
        std::string left_content = "";
        
        if (entry_idx < static_cast<int>(entries.size())) {
            const auto& entry = entries[entry_idx];
            bool is_selected = (entry_idx == selected_index);
            
            // Format line contents
            std::string icon = "📄 ";
            std::string item_color = TUI::COLOR_FILE;
            
            if (entry.is_directory) {
                icon = "📁 ";
                item_color = TUI::COLOR_DIR;
            } else if (entry.is_executable) {
                icon = "⚡ ";
                item_color = TUI::COLOR_EXE;
            } else if (entry.is_zip) {
                icon = "📦 ";
                item_color = TUI::COLOR_ZIP;
            } else if (entry.is_system) {
                icon = "🔒 ";
                item_color = TUI::COLOR_SYS;
            }

            // Filename column (fits left_panel_width - size_column - space)
            int name_width = left_panel_width - 15;
            std::string name_part = icon + entry.name;
            if (name_part.length() > static_cast<size_t>(name_width)) {
                name_part = name_part.substr(0, name_width - 3) + "...";
            } else {
                name_part.append(name_width - name_part.length(), ' ');
            }

            // Size column
            std::string size_part = entry.size_str;
            if (size_part.length() < 12) {
                size_part.insert(0, 12 - size_part.length(), ' ');
            }

            std::string line_text = name_part + " " + size_part;
            
            if (is_selected) {
                left_content = TUI::COLOR_SELECTED + line_text + TUI::RESET;
            } else {
                left_content = item_color + line_text + TUI::RESET;
            }
        } else {
            // Empty spacer line
            left_content.append(left_panel_width, ' ');
        }
        
        screen << left_content;

        // Draw middle divider
        screen << TUI::COLOR_BORDER << TUI::BOX_VLINE << TUI::RESET;

        // --- RIGHT PANEL (File Preview) ---
        std::string right_content = "";
        if (i < static_cast<int>(current_preview.size())) {
            std::string line = current_preview[i];
            
            // Truncate to panel width
            if (line.length() > static_cast<size_t>(right_panel_width)) {
                line = line.substr(0, right_panel_width - 3) + "...";
            }
            
            right_content = TUI::COLOR_TEXT_NORM + line;
            if (right_content.length() < static_cast<size_t>(right_panel_width)) {
                right_content.append(right_panel_width - line.length(), ' ');
            }
        } else {
            right_content.append(right_panel_width, ' ');
        }
        
        screen << right_content << TUI::RESET;

        // Draw right border
        screen << TUI::COLOR_BORDER << TUI::BOX_VLINE << TUI::RESET << "\n";
    }

    // 4. Panel Bottom Border (Line panel_height + 3)
    screen << TUI::COLOR_BORDER << TUI::BOX_BL;
    for (int i = 0; i < left_panel_width; i++) screen << TUI::BOX_HLINE;
    screen << TUI::BOX_TEE_B;
    for (int i = 0; i < right_panel_width; i++) screen << TUI::BOX_HLINE;
    screen << TUI::COLOR_BORDER << TUI::BOX_BR << TUI::RESET << "\n";

    // 5. Shortcut Info Bar (Line panel_height + 4)
    std::string shortcut_bar = " " + TUI::BOLD + "Keys:" + TUI::RESET + 
        " [Enter] Open | [Back] Up | [C] Create | [X] Delete | [R] Rename | [F] Filter | [Y/P] Copy/Paste | [Q] Quit";
    
    // Pad shortcuts
    if (shortcut_bar.length() < static_cast<size_t>(width)) {
        shortcut_bar.append(width - shortcut_bar.length(), ' ');
    }
    screen << TUI::COLOR_TEXT_MUTE << shortcut_bar << TUI::RESET << "\n";

    // 6. Action Status Bar (Line panel_height + 5)
    std::string status_bar = " Status: " + status_msg;
    if (!filter_str.empty()) {
        status_bar += " (Filter active: \"" + filter_str + "\")";
    }

    if (status_bar.length() > static_cast<size_t>(width)) {
        status_bar = status_bar.substr(0, width - 3) + "...";
    } else {
        status_bar.append(width - status_bar.length(), ' ');
    }

    screen << status_clr << status_bar << TUI::RESET;

    // Render buffer to screen
    std::cout << screen.str() << std::flush;
}

std::string readInputFromConsole(const std::string& prompt) {
    int width, height;
    TUI::getTerminalSize(width, height);

    // Clear command bar and show prompt
    std::string empty_line(width, ' ');
    std::cout << TUI::moveTo(1, height) << empty_line;
    std::cout << TUI::moveTo(1, height) << TUI::COLOR_WARNING << " " << prompt << TUI::RESET << "\033[?25h" << std::flush;

    std::string result = "";
    while (true) {
        int c = _getch();
        if (c == 27) { // Escape
            result = "";
            break;
        } else if (c == 13) { // Enter
            break;
        } else if (c == 8) { // Backspace
            if (!result.empty()) {
                result.pop_back();
                // Clear input line and redraw
                std::cout << TUI::moveTo(1, height) << empty_line;
                std::cout << TUI::moveTo(1, height) << TUI::COLOR_WARNING << " " << prompt << TUI::RESET << result << std::flush;
            }
        } else if (c >= 32 && c <= 126) { // Printable characters
            if (result.length() < 100) { // Limit length
                result.push_back(static_cast<char>(c));
                std::cout << static_cast<char>(c) << std::flush;
            }
        }
    }

    std::cout << "\033[?25l" << std::flush; // Hide cursor again
    return result;
}

bool confirmAction(const std::string& question) {
    int width, height;
    TUI::getTerminalSize(width, height);
    
    std::string empty_line(width, ' ');
    std::cout << TUI::moveTo(1, height) << empty_line;
    std::cout << TUI::moveTo(1, height) << TUI::COLOR_WARNING << " " << question << " (y/N): " << TUI::RESET << std::flush;

    int c = _getch();
    bool confirmed = (c == 'y' || c == 'Y');
    return confirmed;
}

void handleKeyPress() {
    int c = _getch();

    if (c == 0 || c == 224) {
        // Arrow/special keys
        int c2 = _getch();
        switch (c2) {
            case 72: // Up Arrow
                if (selected_index > 0) {
                    selected_index--;
                    refreshDirectory();
                }
                break;
            case 80: // Down Arrow
                if (selected_index < static_cast<int>(entries.size()) - 1) {
                    selected_index++;
                    refreshDirectory();
                }
                break;
            case 75: // Left Arrow
                current_path = current_path.parent_path();
                selected_index = 0;
                scroll_offset = 0;
                filter_str = ""; // reset filter when moving directory
                refreshDirectory();
                status_msg = "Moved to " + current_path.string();
                status_clr = TUI::COLOR_SUCCESS;
                break;
            case 77: // Right Arrow
                if (!entries.empty()) {
                    const auto& entry = entries[selected_index];
                    if (entry.is_directory) {
                        current_path = entry.path;
                        selected_index = 0;
                        scroll_offset = 0;
                        filter_str = "";
                        refreshDirectory();
                        status_msg = "Moved to " + current_path.string();
                        status_clr = TUI::COLOR_SUCCESS;
                    } else {
                        // Open file on Windows using default app
                        ShellExecuteW(NULL, L"open", entry.path.wstring().c_str(), NULL, NULL, SW_SHOWNORMAL);
                        status_msg = "Opening: " + entry.name;
                        status_clr = TUI::COLOR_SUCCESS;
                    }
                }
                break;
        }
    } else {
        // Normal characters
        switch (c) {
            case 'q': case 'Q': case 27: // 'q' or Esc
                is_running = false;
                break;
            case 8: // Backspace (Go to parent directory)
                current_path = current_path.parent_path();
                selected_index = 0;
                scroll_offset = 0;
                filter_str = "";
                refreshDirectory();
                status_msg = "Moved to " + current_path.string();
                status_clr = TUI::COLOR_SUCCESS;
                break;
            case 13: // Enter
                if (!entries.empty()) {
                    const auto& entry = entries[selected_index];
                    if (entry.is_directory) {
                        current_path = entry.path;
                        selected_index = 0;
                        scroll_offset = 0;
                        filter_str = "";
                        refreshDirectory();
                        status_msg = "Moved to " + current_path.string();
                        status_clr = TUI::COLOR_SUCCESS;
                    } else {
                        ShellExecuteW(NULL, L"open", entry.path.wstring().c_str(), NULL, NULL, SW_SHOWNORMAL);
                        status_msg = "Opening: " + entry.name;
                        status_clr = TUI::COLOR_SUCCESS;
                    }
                }
                break;
            case 'c': case 'C': { // Create
                std::string name = readInputFromConsole("Enter name (append / for directory):");
                if (name.empty()) {
                    status_msg = "Action cancelled.";
                    status_clr = TUI::COLOR_WARNING;
                    break;
                }

                fs::path target = current_path / name;
                
                try {
                    if (name.back() == '/' || name.back() == '\\') {
                        // Create directory
                        fs::create_directory(target);
                        status_msg = "Created directory: " + name;
                    } else {
                        // Create file
                        std::ofstream file(target);
                        file.close();
                        status_msg = "Created file: " + name;
                    }
                    status_clr = TUI::COLOR_SUCCESS;
                } catch (const std::exception& e) {
                    status_msg = "Error: " + std::string(e.what());
                    status_clr = TUI::COLOR_ERROR;
                }
                
                refreshDirectory();
                break;
            }
            case 'x': case 'X': { // Delete
                if (entries.empty()) break;
                const auto& entry = entries[selected_index];
                
                std::string prompt = "Delete " + (entry.is_directory ? std::string("directory") : std::string("file")) + " '" + entry.name + "'?";
                if (confirmAction(prompt)) {
                    try {
                        fs::remove_all(entry.path);
                        status_msg = "Deleted: " + entry.name;
                        status_clr = TUI::COLOR_SUCCESS;
                    } catch (const std::exception& e) {
                        status_msg = "Delete failed: " + std::string(e.what());
                        status_clr = TUI::COLOR_ERROR;
                    }
                    refreshDirectory();
                } else {
                    status_msg = "Delete cancelled.";
                    status_clr = TUI::COLOR_WARNING;
                }
                break;
            }
            case 'r': case 'R': { // Rename
                if (entries.empty()) break;
                const auto& entry = entries[selected_index];
                
                std::string new_name = readInputFromConsole("New name for '" + entry.name + "':");
                if (new_name.empty()) {
                    status_msg = "Rename cancelled.";
                    status_clr = TUI::COLOR_WARNING;
                    break;
                }

                fs::path target = current_path / new_name;
                try {
                    fs::rename(entry.path, target);
                    status_msg = "Renamed: " + entry.name + " -> " + new_name;
                    status_clr = TUI::COLOR_SUCCESS;
                } catch (const std::exception& e) {
                    status_msg = "Rename failed: " + std::string(e.what());
                    status_clr = TUI::COLOR_ERROR;
                }
                
                refreshDirectory();
                break;
            }
            case 'f': case 'F': { // Filter
                filter_str = readInputFromConsole("Filter files matching:");
                refreshDirectory();
                status_msg = "Filter set. Matches displayed.";
                status_clr = TUI::COLOR_SUCCESS;
                break;
            }
            case 'y': case 'Y': { // Copy (add to clipboard)
                if (entries.empty()) break;
                clipboard_path = entries[selected_index].path;
                is_copy_operation = true;
                status_msg = "Copied '" + entries[selected_index].name + "' to clipboard. Press [P] to paste.";
                status_clr = TUI::COLOR_SUCCESS;
                break;
            }
            case 'u': case 'U': { // Cut (add to clipboard)
                if (entries.empty()) break;
                clipboard_path = entries[selected_index].path;
                is_copy_operation = false;
                status_msg = "Cut '" + entries[selected_index].name + "' to clipboard. Press [P] to paste.";
                status_clr = TUI::COLOR_SUCCESS;
                break;
            }
            case 'p': case 'P': { // Paste
                if (clipboard_path.empty()) {
                    status_msg = "Clipboard is empty. Copy/cut a file first!";
                    status_clr = TUI::COLOR_WARNING;
                    break;
                }
                
                performCopy(clipboard_path);
                break;
            }
        }
    }
}

void performCopy(const fs::path& src) {
    if (!fs::exists(src)) {
        status_msg = "Source file no longer exists!";
        status_clr = TUI::COLOR_ERROR;
        clipboard_path.clear();
        return;
    }

    fs::path dest = current_path / src.filename();
    
    // Prevent pasting onto itself
    if (src == dest) {
        status_msg = "Cannot paste a file onto itself!";
        status_clr = TUI::COLOR_WARNING;
        return;
    }

    try {
        if (is_copy_operation) {
            // Perform Copy
            status_msg = "Copying files... please wait.";
            renderScreen();
            
            fs::copy(src, dest, fs::copy_options::recursive | fs::copy_options::overwrite_existing);
            status_msg = "Pasted: " + src.filename().string();
        } else {
            // Perform Move (Cut)
            fs::rename(src, dest);
            status_msg = "Moved: " + src.filename().string();
            clipboard_path.clear(); // clear clipboard after cut-paste
        }
        status_clr = TUI::COLOR_SUCCESS;
    } catch (const std::exception& e) {
        status_msg = "Paste failed: " + std::string(e.what());
        status_clr = TUI::COLOR_ERROR;
    }

    refreshDirectory();
}
