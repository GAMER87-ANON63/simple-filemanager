#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <windows.h>

namespace TUI {

    // Color definitions using ANSI 24-bit Truecolor
    const std::string RESET = "\033[0m";
    const std::string BOLD = "\033[1m";
    const std::string DIM = "\033[2m";
    const std::string UNDERLINE = "\033[4m";

    // Palette Colors (Modern Tailwind CSS - Dark Theme inspired)
    const std::string COLOR_BG_DARK   = "\033[48;2;15;23;42m";      // slate-900 background
    const std::string COLOR_TEXT_MUTE = "\033[38;2;100;116;139m";   // slate-500 (muted text)
    const std::string COLOR_TEXT_NORM = "\033[38;2;226;232;240m";   // slate-200 (normal text)
    
    const std::string COLOR_BORDER    = "\033[38;2;71;85;105m";     // slate-600 (borders)
    const std::string COLOR_DIR       = "\033[1m\033[38;2;59;130;246m";  // blue-500 (directories)
    const std::string COLOR_EXE       = "\033[38;2;34;197;94m";     // green-500 (executables)
    const std::string COLOR_FILE      = "\033[38;2;203;213;225m";    // slate-300 (standard files)
    const std::string COLOR_ZIP       = "\033[38;2;234;179;8m";     // yellow-500 (compressed/zip)
    const std::string COLOR_SYS       = "\033[38;2;236;72;153m";     // pink-500 (system/hidden)

    const std::string COLOR_HEADER    = "\033[48;2;30;41;59m\033[38;2;248;250;252m"; // slate-800 bg, slate-50 fg
    const std::string COLOR_SELECTED  = "\033[48;2;14;165;233m\033[38;2;255;255;255m"; // sky-500 bg, white fg
    
    // Status message colors
    const std::string COLOR_SUCCESS   = "\033[38;2;34;197;94m";     // green-500
    const std::string COLOR_WARNING   = "\033[38;2;249;115;22m";    // orange-500
    const std::string COLOR_ERROR     = "\033[38;2;239;68;68m";     // red-500

    // Box drawing characters (Unicode UTF-8)
    const std::string BOX_HLINE = "─";
    const std::string BOX_VLINE = "│";
    const std::string BOX_TL    = "┌";
    const std::string BOX_TR    = "┐";
    const std::string BOX_BL    = "└";
    const std::string BOX_BR    = "┘";
    const std::string BOX_TEE_L = "├";
    const std::string BOX_TEE_R = "┤";
    const std::string BOX_TEE_T = "┬";
    const std::string BOX_TEE_B = "┴";
    const std::string BOX_CROSS = "┼";

    // Setup console modes for UTF-8 and ANSI escape codes on Windows
    inline bool initializeConsole() {
        // Set console output and input to UTF-8
        SetConsoleOutputCP(CP_UTF8);
        SetConsoleCP(CP_UTF8);

        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        if (hOut == INVALID_HANDLE_VALUE) return false;

        DWORD dwMode = 0;
        if (!GetConsoleMode(hOut, &dwMode)) return false;

        // Enable Virtual Terminal Processing (ANSI Escape Sequences)
        dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
        if (!SetConsoleMode(hOut, dwMode)) return false;

        // Hide cursor to prevent flicker
        std::cout << "\033[?25l" << std::flush;
        return true;
    }

    inline void restoreConsole() {
        // Show cursor again on exit
        std::cout << "\033[?25h" << RESET << "\033[2J\033[H" << std::flush;
    }

    inline void getTerminalSize(int& width, int& height) {
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi)) {
            width = csbi.srWindow.Right - csbi.srWindow.Left + 1;
            height = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
        } else {
            width = 80;
            height = 24;
        }
    }

    // Helper to truncate a UTF-8 string to a specific width
    inline std::string truncateString(const std::string& str, size_t width) {
        if (str.length() <= width) return str;
        // Basic truncation, doesn't account for multi-byte characters perfectly, 
        // but for standard ASCII paths/files it's robust. We add '..' to show truncation.
        if (width <= 3) return "...";
        return str.substr(0, width - 3) + "...";
    }

    // Move cursor to coordinate (1-based)
    inline std::string moveTo(int x, int y) {
        return "\033[" + std::to_string(y) + ";" + std::to_string(x) + "H";
    }

    // Clear screen
    inline void clearScreen() {
        std::cout << "\033[2J\033[H" << std::flush;
    }
}
